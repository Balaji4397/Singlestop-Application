from setuptools import setup

setup(
    name='E-Commerce',
    version='2.0.0',
    packages=['src', 'src.main', 'src.config'],
    url='https://github.com/Balaji4397',
    license='',
    author='balaji.a.arunachalam',
    author_email='balaji.arun97@gmail.com',
    description='E-commerce project complete wheel file'
)